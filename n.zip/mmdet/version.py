# GENERATED VERSION FILE
# TIME: Mon Jan 24 14:49:39 2022

__version__ = '1.0.rc0+unknown'
short_version = '1.0.rc0'
